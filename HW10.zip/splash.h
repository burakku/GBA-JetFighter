#ifndef SPLASH_BITMAP_H
#define SPLASH_BITMAP_H
extern const unsigned short splash[38400];
#define SPLASH_WIDTH 240
#define SPLASH_HEIGHT 160
#endif