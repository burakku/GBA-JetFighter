#ifndef TARGET_BITMAP_H
#define TARGET_BITMAP_H
extern const unsigned short target[80];
#define TARGET_WIDTH 8
#define TARGET_HEIGHT 10
#endif