#ifndef FIGHTER_BITMAP_H
#define FIGHTER_BITMAP_H
extern const unsigned short fighter[506];
#define FIGHTER_WIDTH 22
#define FIGHTER_HEIGHT 23
#endif